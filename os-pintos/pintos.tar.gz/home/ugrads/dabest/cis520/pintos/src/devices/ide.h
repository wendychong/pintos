#ifndef DEVICES_IDE_H
#define DEVICES_IDE_H

void ide_init (void);

#endif /* devices/ide.h */
